// creating a variable and storing the number zero.
var likeCount = 0;
// creating a function that will increment the like count variable.
function increaseLikes() {
    // calling the like count variable and assigning it a new property everytime it is called that increments by one.
    likeCount = likeCount + 1;
}
