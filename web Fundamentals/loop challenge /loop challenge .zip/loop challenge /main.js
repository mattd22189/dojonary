function oddValues(){
for (count=1; count<=20; count++){
    if (count%2 == 1){
        console.log(count)
        }
    }
}
//console.log(oddValues())

function multiplesOf3(){
    for(count=100; count>=0; count--){
        if(count%3 == 0){
            console.log(count)
        }
    }

}
//console.log(multiplesOf3());

array=[4,2.5,1,-0.5,-2,-3.5]
function printSequence(){
    for( let i=0 ; array.length ; i++){
        console.log(array)
    }
}
//console.log(array)
countStart =1;
countEnd = 100;
function sigma(){
    while(countStart <= countEnd ){
    console.log( count + "+" + (count+1)  );
    count++
    
}
        array = [result]
}
console.log(sigma())


function Factorial(){
    
}